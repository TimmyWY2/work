#!/bin/bash

set -e

source utils.sh

function usage()
{
    echo "Usage: $(basename $0) [public ssh key]"
    echo ""
    echo "Options:"
    echo "    [public ssh key]    the public ssh key can be a file or the contents of a file"
    echo "    -h, --help          print this info"
    echo ""
    echo "Examples:"
    echo "    $ ./$(basename $0) ~/.ssh/id_rsa.pub"
    echo "    $ cat ~/.ssh/id_rsa.pub | ./$(basename $0)"
    exit 0
}

precheck

if [ $# -eq 1 ]; then
    if [ "x$1" = "x-h" -o "x$1" = "x--help" ]; then
        usage
    elif [ -f $1 -a -r $1 ]; then
        echo "Adding public ssh key $1."
        pub_key_string=$(cat $1)
    else
        echo "Failed to read \"$1\"."
        echo ""
        usage
    fi
elif [ $# -eq 0 ]; then
    # if stdin connected with terminal
    if [ -t 0 ]; then
        echo -n "Reading public ssh key from stdin: "
    else
        echo "Read public ssh key from pipe."
    fi
    read pub_key_string
fi

./.mesos-exec $CONTAINER_ID $CONTAINER_HOSTNAME:5051 \
    "echo $pub_key_string >> /mnt/volume/newroot/root/.ssh/authorized_keys" &&
    echo ""
    echo "Done" ||
    echo "Failed"
