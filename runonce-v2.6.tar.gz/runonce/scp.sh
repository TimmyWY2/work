#!/bin/bash

set -e

source ./utils.sh
precheck

function usage()
{
    echo "Usage: $(basename $0) <file1[,file2,dir1]> <remote-path>"
    echo ""
    echo "Examples:"
    echo ""
    echo "    1. copy local file1, file2 to remote /tmp directory"
    echo "        $ ./$(basename $0) file1 file2 /tmp"
    echo "    2. copy local file1, dir1 recursively to remote /tmp directory"
    echo "        $ ./$(basename $0) file1 dir1 /tmp"
    exit 0
}

if [ $# -lt 2 ]; then
    usage
fi

last=${@: -1}
array=${@:1:$#-1}

scp -r -P $PORT_22 $array root@$CONTAINER_HOSTNAME:$last
