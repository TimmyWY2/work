#!/bin/bash

set -e

source utils.sh
precheck

ssh -p $PORT_22 root@$CONTAINER_HOSTNAME
