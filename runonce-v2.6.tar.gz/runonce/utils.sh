#!/bin/bash

set -e

function precheck()
{
    if [ ! -f .env ]; then
        echo -e "\nrunonce.pex is NOT RUNNING!\n"
        exit 1
    fi

    source .env
}
